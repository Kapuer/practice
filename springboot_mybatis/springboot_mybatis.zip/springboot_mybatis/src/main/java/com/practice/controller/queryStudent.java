package com.practice.controller;

import com.practice.domain.student;
import com.practice.mapper.studentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@ResponseBody
public class queryStudent {
   studentMapper mystudent;
    @RequestMapping("query")
    List<student> querystudentlist(){

        List<student> s= mystudent.querystudentlist();
            return s;
    }
}
